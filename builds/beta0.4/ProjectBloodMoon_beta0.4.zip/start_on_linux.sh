#! /bin/bash

cd "${0%/*}"
java -jar ProjectBloodMoon.jar || echo Components to run the game are missing. Please download them at https://drive.google.com/drive/folders/1_aDBmAlZtB544GnEiuPZ-ENGvlCl6Lm8?usp=sharing
